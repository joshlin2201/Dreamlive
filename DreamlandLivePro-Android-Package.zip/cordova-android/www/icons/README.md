# Dreamland Maid Cafe App Icons

Please add your Dreamland Maid Cafe logo images here with these names:
- icon-192.png (192x192 pixels)
- icon-512.png (512x512 pixels)
- icon-1024.png (1024x1024 pixels) - for iPad

Recommended: Use the circular pink maid cafe logo from your website!

For now, the app will use a pink gradient placeholder.
